

$(function() {


	$("body").prepend("<div class='tg-sample-nav'><a href='/widget'><div class='tg-logo'><img src='img/tg_logo.jpg'></a> DEMOS</div>"
	+ "<ul>"
	+ "<li><a href='basic.html'>bare bones</a></li>"
	+ "<li><a href='kitchen_sink.html'>kitchen sink</a></li>"
	+ "<li><a href='presentation.html'>2+ timelines</a></li>"
	+ "<li><a href='custom_tags.html'>tags interface</a></li>"
	+ "<li><a href='inverted.html'>top-down (inverted) timeline</a></li>"
	+ "<li><a href='load_object.html'>load data from object</a></li>"
	+ "<li><a href='lanes.html'>topical lanes</a></li>"
	+ "<li><a href='full_window.html'>full-window</a></li>"
	+ "</ul></div>");


});