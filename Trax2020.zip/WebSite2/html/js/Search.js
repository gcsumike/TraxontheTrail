﻿/*
Functions
       loadData() - Makes an ajax request to the server for data used to populate the table for the first time.
       getData() - Converts the search form into a json which is then sent to the server by ajax POST the server returns a JSON (data) which is used to populate the table with the query results.
       ConvertFormToJSON() - Calls serializeArray on the search form converting it to an array, the array is then converted to a JSON and returned.
...

 */
var timelineObj = [];

var tg_instance = {};

var tg1 = null; //Object for the timeline

var map;    //Object for the map

var map_markers = []; //holds all map markers that can be displayed on the map

var map_cords = []; //holds the lat and lng value for each row in the table 

//col, (stands for column), contains information for the tabulator table, defines the columns by title and
//what field from the query data will be used to fill the table rows, cellClick calls the function showEntry() when a cell is clicked
var col = {
    height: 650,

    layout: "fitColumns", //fit columns to width of table

    pagination: "local",

    paginationSize: 18,

    columns: [ //Define Table Columns

        { title: "Song Title", field: "song_title", cellClick: function (e, cell) { showEntry(e, cell); }, minWidth: 300, },

        { title: "Candidate", field: "candidate", cellClick: function (e, cell) { showCandidateEntry(e, cell); }, minWidth: 150, },

        { title: "Event Title", field: "event_title", minWidth: 550, },

        {
            title: "Date", field: "date", minWidth: 100, formatter: function (cell, formatterParams) {
                return cell.getValue().substr(0,10); //return the contents of the cell;
            },}

    ],

}
//actions to perform when the html document is ready for view
$(document).ready(function () {

    $("#map").hide();

    $("#timeline").hide();

    $("#entry_info").hide();

    $("#table_div").tabulator(col); //set the columns

    loadData();

    $("#song_title").keyup(function (event) {
        if (event.keyCode == 10 || event.keyCode == 13) {
            $("#search_button").click();
        }
    });
    $("#event_title").keyup(function (event) {
        if (event.keyCode == 10 || event.keyCode == 13) {
            $("#search_button").click();
        }
    });

    $("#start_date").datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        changeYear: true
    });

    $("#end_date").datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        changeYear: true
    });

    $.ajax({
        url: "/genres",

        type: "get",

        async: true,

        dataType: 'json',
        success: function (data) {
            data.forEach(function (row) {
                $("#genre").append(
                    $("<option></option>").text(row.genre).val(row.genre)
                );
            });
        }
    });

    $.ajax({
        url: "/candidates",

        type: "get",

        async: true,

        dataType: 'json',
        success: function (data) {
            data.forEach(function (row) {
                $("#candidate").append(
                    $("<option></option>").text(row.candidate).val(row.candidate)
                );
            });
        }
    });

    $.ajax({
        url: "/music_types",

        type: "get",

        async: true,

        dataType: 'json',
        success: function (data) {
            data.forEach(function (row) {
                $("#music_type").append(
                    $("<option></option>").text(row.music_type).val(row.music_type)
                );
            });
        }
    });

});



//Handle server connection and data validation
function validate() {
    //check song title

    getData();

}


function candidateSearch(name) {
    $("#candidate_name option[value='" + name + "']").prop('selected', true);
}


//loadData() makes an ajax request the the server for the data used to populate the table the first time
function loadData() {

    $.ajax({

        url: "/select",

        type: "get",

        async: true,

        dataType: 'json',

        success: function (data) {

            tableData = data;

            getCords(data);

            buildObjArr(data);

            $("#table_div").tabulator("setData", data);

        },

    });
}
//getData() converts the search form into a json which is then sent to the server by ajax POST
//the server returns a JSON (data) which is used to populate the table with the query results
function getData() {

    var x = ConvertFormToJSON();

    $.ajax({

        type: "POST",

        url: "/selectItems",

        data: x,

        dataType: "json"

    })

        .done(function (data) {

            deleteMarkers();

            getCords(data);

            buildObjArr(data);

            $("#table_div").tabulator("setData", data);

        })

        .fail(function () {

            alert("Failed"); 

        });


}


//ConvertFormToJSON() calls serializeArray on the search form converting it to a array, the array is then converted to a JSON and returned
function ConvertFormToJSON() {

    var array = $('#search').serializeArray();

    var json = {};


    $.each(array, function () {

        json[this.name] = this.value|| '';

    });


    return json;

}

//showMap() is called by the button (id = map_button), hides all elements except the map
//if the map has not been created yet, it creates it.
function showMap() {
    $("#search_button").attr("disabled", "disabled");
    stopVideo();
    $("#spotify_player").prop("src", "");

    $("#table_div").hide();

    $("#timeline").hide();

    $("#map").show();

    $("#candidate_entry").hide();

    $("#entry_info").hide();

    if (map == null) {

        initMap();  

    }

    placeMarkers(map_cords);

    google.maps.event.trigger(map, 'resize'); //refresh the map
}


//Called when a cell in the table with data that can be displayed is clicked
//hides all elements except the entry page, populates the entry page with complete data from the table
function showEntry(e, cell) {
    $("#search_button").attr("disabled", "disabled");

    $("#table_div").hide();

    $("#timeline").hide();

    $("#map").hide();

    $("#entry_info").show();

    $("#candidate_entry").hide();


    buildEntry(cell.getData());

}

function showCandidateEntry(e, cell) {
    var data = cell.getData();
    $("#search_button").attr("disabled", "disabled");

    $("#table_div").hide();

    $("#timeline").hide();

    $("#map").hide();

    $("#candidate_entry").show();

    buildCandidateEntry(data);

}
//buildEntry(data) takes the data stored in the table and displays the hidden attributes in a separate view
function buildEntry(data) {

    var d = "n/a";

    if (data.date) {

        d = data.date.substr(0, 10)

    }


    $("#entry_song").html("<i>" + data.song_title + "</i>");

    $("#entry_performer").html("<b>Performer/Composer: </b> " + data.performer);

    $("#entry_candidate").html("<b>Candidate: </b> " + data.candidate);

    $("#entry_genre").html("<b>Genre: </b> " + data.genre);

    $("#entry_event_title").html("<b>Event Title: </b> " + data.event_title);

    $("#entry_event_type").html("<b>Type of Event/Media: </b> " + data.event_type);

    $("#entry_music_type").html("<b>Type of Music: </b> " + data.music_type);

    $("#entry_date").html("<b>Date: </b> " + d);

    $("#entry_notes").html("<b>Notes: </b> " + data.notes);


    if (data.youtube_link == "" || data.youtube_link == null || data.youtube_link == "n/a") {
        $("#youtube_player").hide();
    }
    else {
        $("#youtube_player").show();
        loadYoutubeVideo(data.youtube_link);
    }

    if (data.spotify_link == "" || data.spotify_link == null || data.spotify_link == "n/a") {
        $("#spotify_player").hide();

    }
    else {
        $("#spotify_player").prop("src", "https://open.spotify.com/embed?uri=spotify:track:" + data.spotify_link);
        $("#spotify_player").show();
    }

    if (data.soundcloud_link == "" || data.soundcloud_link == null || data.soundcloud_link == "n/a") {
        $("#soundcloud_player").hide();
    }
    else {
        $("#soundcloud_player").show();
        $("#soundcloud_link").attr("href", data.soundcloud_link);
        $("#soundcloud_link").html("<i style='color: white'>Link to soundcloud</i>");
    }
    if (data.general_link == "" || data.general_link == null || data.general_link == "n/a") {
        $("#external_div").hide();
    }
    else {
        $("#external_div").show();
        $("#external_link").attr("href", data.general_link);
        $("#external_link").html("<i style='color: white'>Link to source</i>");
    }


}

///////////////////////////////////////////////////////////////////////////////////////////////
function buildCandidateEntry(data) {

    var na = "n/a";

    getCandidateBio(data.candidate);

    $("#candidate_entry_name").html(data.candidate);
    $("#candidate_party").html("<b>Political Party</b>: " + data.party);
}

function getCandidateBio(name) {
    var json = { "candidate": name }


    $.ajax({

        type: "POST",

        url: "/bio",

        data: json,

        dataType: "json"

    })

        .done(function (data) {
            if (data[0].bio != null)        
                $("#candidate_bio").html(data[0].bio);

        })
        .fail(function () {

            alert("Failed");

        });


}
//////////////////////////////////////////////////////////////////////////////////////////////


//showTable() is called by the button (id = table_button), hides all elements except the table
function showTable() {
    $("#search_button").removeAttr("disabled");
    stopVideo();
    $("#spotify_player").prop("src", "");

    $("#table_div").show();

    $("#timeline").hide();

    $("#candidate_entry").hide();

    $("#entry_info").hide();

    $("#map").hide();

}

//////////////MAP//////////////////

//initMap() creates the google map object
function initMap() {

    var atlanta = { lat: 33.748995, lng: -84.387982 };

    var macon = { lat: 32.840695, lng: -83.632402 };

    map = new google.maps.Map(document.getElementById('map'), {

        zoom: 4,

        center: { lat: 58, lng: -148 },

        disableDefaultUI: true

    });

}

//getCords() pulls the lat and lng values from the table data for each row add the lat and lng values to the map_cords array
function getCords(data) {

    data.forEach(function (row) {

        if (row.lat != null && row.lng != null) {

            map_cords.push({song: row.song_title, candidate: row.candidate, city: row.city, state: row.state, zip: row.zip, lat: row.lat, lng: row.lng });

        }

    });

}

// Sets the map on all markers in the array.
function setMapOnAll(mapValue) {

    for (var i = 0; i < map_markers.length; i++) {
        map_markers[i].setMap(mapValue);
    }


}

// Removes the markers from the map, but keeps them in the array.
function clearMarkers() {

    setMapOnAll(null);


}

// Shows any markers currently in the array.
function showMarkers() {

    setMapOnAll(map);

}

// Deletes all markers in the array by removing references to them.
function deleteMarkers() {

    clearMarkers();

    map_markers = [];

    map_cords = [];

}

//placeMarkers() places markers on the google map for each entry that contains a zipcode with latitude and longnitude
function placeMarkers(data) {

    data.forEach(function (row) {
        var infowindow;
        var marker;
        if (row.lat != null && row.lng != null) {
            infowindow = new google.maps.InfoWindow({
                content: "<b>Song Title</b>: " + row.song + "<br /><b>Candidate</b>:" + row.candidate + "<br /><b>City</b>: " + row.city + "<br /> <b>State</b>:" + row.state + "<br/><b>Census Info</b>: <a target='_blank' href=\"https://factfinder.census.gov/bkmk/cf/1.0/en/zip/" + row.zip.substr(0,5) + "/ALL\" style=\"color: blue\"><i>U.S. Census</i></a>"
            });

            marker = new google.maps.Marker({

                position: { lat: row.lat, lng: row.lng },

                map: map

            });

            marker.addListener('click', function () {
                infowindow.open(map, this);
            });

            map_markers.push(marker);


        }

    });
}


//Youtube Player
var tag = document.createElement('script');
var firstScriptTag;
var player;

    tag.src = "https://www.youtube.com/iframe_api";
    firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    function onYouTubeIframeAPIReady() {
        player = new YT.Player('youtube_player', {
            height: '200',
            width: '300',
        });
    }


function loadPlayers(youtube, spotify, soundcloud) {
    loadYoutubeVideo(youtube); 

}
// 3. This function creates an <iframe> (and YouTube player)
//    after the API code downloads.


function loadYoutubeVideo(id) {
    player.cueVideoById({
        videoId: id,
        suggestedQuality: String
    });
}

function stopVideo() {
    player.stopVideo();
}


function showTimeline() {

    $("#search_button").attr("disabled", "disabled");
    stopVideo();
    $("#spotify_player").prop("src", "");

    $("#table_div").hide();

    $("#timeline").show();

    $("#map").hide();

    $("#entry_info").hide();


    loadTimeline();
    setTimeout(function () {
        addEvents();
    }, 500);
}


function loadTimeline() {


    tg1 = $("#timeline").timeline({
        "data_source": "json/test.json",
        "icon_folder": "timeglider/icons/",
        "min_zoom": 15,
        "max_zoom": 60,
        "image_lane_height": 100
    });

    tg_instance = tg1.data("timeline");


}

function buildObjArr(data) {

    timelineObj = [];

    data.forEach(function (row) {
        var rando = Math.floor((Math.random() * 1000) + 1);
        timelineObj.push({
            id: "new_" + rando,
            title: row.song_title,
            description: "Performer: " + row.performer + "<br />Candidate: " + row.candidate,
            startdate: row.date.substr(0, 10),
            importance: 50,
            icon: "circle_black.png",
            timelines: ["trailtrax"]
        });


    });
}

function addEvents() {
    var i = 0;
    for (i = 0; i < timelineObj.length; i++) {
        tg_instance.addEvent(timelineObj[i], true);
    }

}