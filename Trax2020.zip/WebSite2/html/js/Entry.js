﻿
    // Wait for the page to load first
    window.onload = function () {
    }
    $(document).ready(function () {
        $("#date").datepicker({ dateFormat: 'yy-mm-dd' });
    });

        function showOptions() {
            var x = document.getElementById("entry_div");
            var y = document.getElementById("admin_div");

            if (x.style.display === "none") {
        x.style.display = "block";
    y.style.display = "none";
                document.getElementById("options").innerHTML = "Admin Options";
            } else {
        x.style.display = "none";
    y.style.display = "block";
                document.getElementById("options").innerHTML = "Entry Form";
            }

        }

        function showText(id) {
            if (id == "lyrics_link") {
        $("#notes_div").hide();
    $("#notes_link").css("background-color", "#103663");
                $("#review_div").hide();
                $("#review_link").css("background-color", "#103663");
                $("#lyrics_div").show();
                $("#lyrics_link").css("background-color","#07264a");

            }
            if (id == "notes_link") {
        $("#notes_div").show();
    $("#notes_link").css("background-color", "#07264a");
                $("#review_div").hide();
                $("#review_link").css("background-color", "#103663");
                $("#lyrics_div").hide();
                $("#lyrics_link").css("background-color", "#103663");

            }
            if (id == "review_link") {
        $("#notes_div").hide();
    $("#notes_link").css("background-color", "#103663");
                $("#review_div").show();
                $("#review_link").css("background-color", "#07264a");
                $("#lyrics_div").hide();
                $("#lyrics_link").css("background-color", "#103663");

            }

        }
//Handle server connection and data validation
        function validate() {
            var valid = true;
            //check song title
            var x;
            if ($("#song_title").attr('val') != null) {
                x = $("#song_title").attr('val').replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\\\$&");
            }
            else {
                x = $("#song_title").val();
            }
            
            if (x == "" || x.length > 100) {
                //highlight textbox

                $("#song_title").css("background-color", "yellow");
                //valid = false


                valid = false;

            }

            $("#song_title").val(x);


            x = $("#event_type").val();
            if (x == "") {
                $("#event_type").css("background-color", "yellow");
                valid = false;
            }

            x = $("#candidate").val();
            if (x == "") {
                $("#candidate").css("background-color", "yellow");
                valid = false;
            }

            x = $("#date").val();
            if (x == "") {
                $("#date").css("background-color", "yellow");

                valid = false;

            }

            if (valid) {
                insertData();

                location.reload();
            }
            else {

                window.alert("Some Fields require your attention.");

            }

        }

        function insertData() {
            var x = ConvertFormToJSON();


            $.ajax({
                type: "POST",
                url: "/insert",
                data: x,
            });

        }

        //ConvertFormToJSON() calls serializeArray on the search form converting it to a array, the array is then converted to a JSON and returned
        function ConvertFormToJSON() {
            var array = $('#entry_form').serializeArray();
            var json = {};

            $.each(array, function () {

                json[this.name] = this.value || '';

            });

            return json;
        }

