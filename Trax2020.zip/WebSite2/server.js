﻿
var mysql = require('mysql'); //Mysql object used to preform actions with mysql database
const express = require('express'); //node.js express object 
const app = express(); //express application object, handles connection requests
const bodyParser = require('body-parser'); // express model allows the body of the request to be parsed into an object
var squel = require("squel"); // SQL statement builder used to create sql statements at runtime
var path = require('path'); // handles paths

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'html')));

//Create the mysql database connection
//TODO CREATE CONFIGURATION FILE TO SET CREDENTIALS 
var pool = mysql.createPool({
    connectionLimit: 100,
    host: "localhost",
    user: "root",
    password: "gcsu",
    database: "traxdb",
    debug: false,
    mutipleStatements: true
});
//Queries database for all values returns all current entries
//****Problem: as the number of entries increases it will likely slow down significantly*****
function select(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var sql = squel.select().from('traxdb.data_table').toString();

        connection.query(sql, function (err, rows, fields) {
            connection.release();
            //if no errors return the rows
            if (!err) {
                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}

//queries table for genres, returns all genres from database
function genres(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var sql = squel.select().from('traxdb.genre').toString();

        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {

                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}
//queries table for candidates, returns all candidates from database
function candidates(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var sql = squel.select().from('traxdb.candidate').toString();

        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {

                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}
//queries table for event_types, returns all event_types from database
function event_types(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var sql = squel.select().from('traxdb.event_type').toString();

        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {

                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}
//queries table for candidate bios, returns all a bio for the candidate chosen from database
function candidate_bio(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;

        var sql = squel.select().from('traxdb.candidate').field("bio").where("candidate = '" + data.candidate + "'").toString();


        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {
                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}
//queries table for genres, returns all genres from database
function music_types(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var sql = squel.select().from('traxdb.music_type').toString();

        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {

                res.json(rows);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}

/////////////
function Insert(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
        //get each element from req 
        var data = req.body;

        var songSql;
        var eventSql;
        var off;


        if (data.official == null) {
            off = "Unofficial";
        }
        else
            off = "Official";


        //add song, move to add event
        songSql = squel.insert().into("traxdb.song")
            .setFields({

                song_title: data.song_title,

                performer: data.performer,

                genre: data.genre,

                music_type: data.music_type,

                youtube_link: data.youtube_link,

                spotify_link: data.spotify_link,

                soundcloud_link: data.soundcloud_link,

                general_link: data.general_link,

                lyrics: data.lyrics,
            })
            .toString();
        connection.query(songSql, function (err, result) {
            if (err) {

                console.log(err);

                throw err;
                return;
            }
            else
                console.log(err);


        });
        ///////////////////////////////
        //TODO
        //CHECK IF ZIPCODE EXISTS, 
        //IF NOT LOOKUP LAT AND LNG through webservice request
        //ADD TO ZIPCODE TABLE
        ///////////////////////////////

        eventSql = squel.insert().into("event")
            .setFields({
                song_title: data.song_title,
                event_title: data.event_title,
                date: data.date,
                candidate: data.candidate,
                city: data.city,
                state: data.state,
                address: data.address,
                zip: data.zip,
                notes: data.notes,
                event_type: data.event_type,
                review_info: data.review_info,
                official: off
            })
            .toString();

        connection.query(eventSql, function (err, result) {
            connection.release();
            if (err) {
                console.log(err);
                res.sendStatus(0);
                throw err;
            }
            else {
                res.sendStatus(1);
            }

        });

    })
}

function selectItems(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;


        var sql;
        var s_date = "'" + data.start_date + "'";
        var e_date = "'" + data.end_date + "'";
        var sqlString = "squel.select().from('traxdb.data_table')";

        if (data.song_title != '') {
            sqlString += ".where(\"song_title LIKE '%\" + [data.song_title] + \"%'\" )";
        }
        if (data.event_title != '') {
            sqlString += ".where(\"event_title LIKE '%\" + [data.event_title] + \"%'\" )";
        }
        if (data.genre != '') {
            sqlString += ".where(\"genre LIKE '%\" + data.genre + \"%'\" )";
        }
        if (data.candidate != '') {
            sqlString += ".where(\"candidate = '\" + data.candidate + \"'\" )";
        }
        if (data.party != '') {
            sqlString += ".where(\"party = '\" + data.party + \"'\" )";
        }
        if (data.state != '') {
            sqlString += ".where(\"state = '\" + data.state + \"'\" )";
        }
        if (data.music_type != '') {
            sqlString += ".where(\"music_type = '\" + data.music_type + \"'\" )";
        }
        if (data.start_date != "" && data.end_date != "") {
            
            sqlString += ".where(\"date >= \" + s_date)";
            sqlString += ".where(\"date <= \" + e_date)";
        }

        sqlString += ".toString()";

        

        sql = eval(sqlString);


        connection.query(sql, function (err, rows, fields) {
            connection.release();
            if (!err) {
                res.json(rows);
            }
            else console.log(err);
        });
        connection.once('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
        
        
    });
}

function addCandidate(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;
        var candidate_name = data.first_name + " " + data.last_name;


        //check if candidate exists
        candidateSql = "SELECT COUNT(*) AS 'count' FROM candidate WHERE candidate = '" + candidate_name+ "'";
        connection.query(candidateSql, function (err, result) {
            if (parseInt(result[0].count) > 0) {
                res.send(0);
            }
        });

        var sql = squel.insert().into("traxdb.candidate").setFields({
            candidate: candidate_name,
            party: data.party,
            bio: data.bio
        }).toString();

        connection.query(sql, function (err, result) {
            connection.release();
            if (!err) {
                res.send(1);
            }
            else {
                console.log(err);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}

function addGenre(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;

        //check if genre exists
        genreSql = "SELECT COUNT(*) AS 'count' FROM genre WHERE genre = '" + data.new_genre + "'";
        connection.query(genreSql, function (err, result) {
            if (parseInt(result[0].count) > 0) {
                res.sendStatus(0);
            }
        });

        var sql = squel.insert().into("traxdb.genre").setFields({
            genre: data.new_genre
        }).toString();

        connection.query(sql, function (err, result) {
            connection.release();
            if (!err) {
                res.send(1);
            }
            else {
                console.log(err);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}

function addMusicType(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;


        //check if music exists
        candidateSql = "SELECT COUNT(*) AS 'count' FROM music_type WHERE music_type = '" + data.new_music + "'";
        connection.query(candidateSql, function (err, result) {
            if (parseInt(result[0].count) > 0) {
                res.send(0);
            }
        });

        var sql = squel.insert().into("traxdb.music_type").setFields({
            music_type: data.new_music
        }).toString();

        connection.query(sql, function (err, result) {
            connection.release();
            if (!err) {
                res.send(1);
            }
            else {
                console.log(err);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}

function addEventType(req, res) {
    pool.getConnection(function (err, connection) {
        if (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }

        var data = req.body;


        //check if music exists
        eventSql = "SELECT COUNT(*) AS 'count' FROM event_type WHERE event_type = '" + data.new_event + "'";
        connection.query(eventSql, function (err, result) {
            if (parseInt(result[0].count) > 0) {
                res.send(0);
            }
        });

        var sql = squel.insert().into("traxdb.event_type").setFields({
            event_type: data.new_event
        }).toString();

        connection.query(sql, function (err, result) {
            connection.release();
            if (!err) {
                res.send(1);
            }
            else {
                console.log(err);
            }
        });
        connection.on('error', function (err) {
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        });
    });
}


app.get('/select', function (req, res) {
    select(req, res);
});

app.get('/genres', function (req, res) {
    genres(req, res);
});

app.get('/candidates', function (req, res) {
    candidates(req, res);
});

app.get('/event_types', function (req, res) {
    event_types(req, res);
});

app.get('/music_types', function (req, res) {
    music_types(req, res);
});

app.post('/selectItems', function (req, res) {
    selectItems(req, res);
});

app.post('/bio', function (req, res) {
    candidate_bio(req, res);
});

app.get('/test', function (req, res) {
    test(req, res);
});

app.post('/insert', function (req, res) {
    Insert(req, res);
});

app.post('/addCandidate', function (req, res) {
    addCandidate(req, res);
});
app.post('/addGenre', function (req, res) {
    addGenre(req, res);
});
app.post('/addMusicType', function (req, res) {
    addMusicType(req, res);
});
app.post('/addEventType', function (req, res) {
    addEventType(req, res);
});

//Listen for a connection from browser
//Change to pull from config file
app.listen(3000, function () {
    console.log('Example app listening on port 3000!')
});

