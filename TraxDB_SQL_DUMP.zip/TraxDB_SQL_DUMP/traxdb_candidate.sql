-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: traxdb
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidate`
--

DROP TABLE IF EXISTS `candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidate` (
  `candidate` varchar(101) NOT NULL,
  `party` varchar(45) DEFAULT NULL,
  `bio` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`candidate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate`
--

LOCK TABLES `candidate` WRITE;
/*!40000 ALTER TABLE `candidate` DISABLE KEYS */;
INSERT INTO `candidate` VALUES ('Bernie Sanders','Democrat','Bernard \"Bernie\" Sanders, born September 8, 1941, is a Democratic candidate for the 2016 presidential election. Previously the longest-serving independent in U.S. Congressional history, he became a Democrat in 2015. He is the junior Senator from Vermont and has been the ranking minority member on the Senate Budget Committee since January 2015.'),('Chris Christie','Republican','Christopher James \"Chris\" Christie, born September 6, 1962, is a Republican candidate in the 2016 presidential election. He is currently the 55th Governor of New Jersey, and he has held this role since January 2010; he was re-elected for a second term in the 2013 election. He has also served as the U.S. Attorney for New Jersey from 2002 to 2008. Although he did not run in the 2012 presidential election, he was the keynote speaker at the 2012 Republican National Convention.'),('Donald Trump','Republican','Donald John Trump, born June 14, 1946, is a Republican candidate in the 2016 presidential election. He is the chairman and president of The Trump Organization and the founder of Trump Entertainment Resorts. He is also a real estate developer, television personality, and business author; he also has a reality show on NBC, The Apprentice.'),('Hillary Clinton','Democrat','Hillary Diane Rodham Clinton, born October 26, 1947, is a Democratic candidate for the 2016 presidential election, and she previously ran in the 2008 presidential election. She served as the 67th Secretary of State under President Barack Obama from 2009 to 2014. Previously, she served as a Senator from New York from 2001 to 2009. She is also the wife of Bill Clinton, the 42nd President of the United States, and she was the First Lady during his presidency from 1993 to 2001.'),('Jeb Bush','Republican','John Ellis \"Jeb\" Bush, born February 11, 1953, is a Republican candidate in the 2016 presidential election. He served as the 43rd Governor of Florida from 1999 to 2007. He is the son of former President George H.W. Bush and a brother of former President George W. Bush.'),('John Doe','Republican',''),('Ted Cruz','Republican','Rafael Edward \"Ted\" Cruz, born December 22, 1970, is a Republican candidate in the 2016 presidential election. He was elected to the U.S. Senate in 2012 as the first Hispanic American to serve as a U.S. Senator from Texas. As a Senator, he is the chairmen of the subcommittee on the Oversight, Agency Action, Federal Rights and Federal Courts U.S. Senate Judiciary Committee and the Commerce Subcommittee on Space, Science and Competitiveness U.S. Senate Commerce Committee.');
/*!40000 ALTER TABLE `candidate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-04 21:38:13
