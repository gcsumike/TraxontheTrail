﻿/*
Functions
       loadData() - Makes an ajax request to the server for data used to populate the table for the first time.
       getData() - Converts the search form into a json which is then sent to the server by ajax POST the server returns a JSON (data) which is used to populate the table with the query results.
       ConvertFormToJSON() - Calls serializeArray on the search form converting it to an array, the array is then converted to a JSON and returned.
...

 */


var timelineObj = [];

var tg_instance = {};

var tg1 = null; //Object for the timeline

var map;    //Object for the map

var map_markers = []; //holds all map markers that can be displayed on the map

var map_cords = []; //holds the lat and lng value for each row in the table 

//col, (stands for column), contains information for the tabulator table, defines the columns by title and
//what field from the query data will be used to fill the table rows, cellClick calls the function showEntry() when a cell is clicked
var col = {
    height: 650,

    layout: "fitColumns", //fit columns to width of table

    pagination: "local",

    paginationSize: 20,

    columns: [ //Define Table Columns

        { title: "Song Title", field: "song_title", cellClick: function (e, cell) { showEntry(e, cell); }, minWidth: 300, },

        { title: "Candidate", field: "candidate_name", cellClick: function (e, cell) { showEntry(e, cell); }, minWidth: 150, },

        { title: "Event Title", field: "event_title", minWidth: 600, },

    ],

}
//actions to perform when the html document is ready for view
$(document).ready(function () {

    $("#map").hide();

    $("#timeline").hide();

    $("#entry_info").hide();

    $("#table_div").tabulator(col); //set the columns

    loadData();

    $("#start_date").datepicker({ dateFormat: 'yy-mm-dd' });

    $("#end_date").datepicker({ dateFormat: 'yy-mm-dd' });

});


//loadData() makes an ajax request the the server for the data used to populate the table the first time
function loadData() {

    $.ajax({

        url: "/select",

        type: "get",

        async: true,

        dataType: 'json',

        success: function (data) {

            tableData = data;

            getCords(data);
            
            buildObjArr(data);

            $("#table_div").tabulator("setData", data);

        },

    });
}
//getData() converts the search form into a json which is then sent to the server by ajax POST
//the server returns a JSON (data) which is used to populate the table with the query results
function getData() {

    var x = ConvertFormToJSON();


    $.ajax({

        type: "POST",

        url: "/selectItems",

        data: x,

        dataType: "json"

    })

        .done(function (data) {

            deleteMarkers();

            getCords(data);
            
            buildObjArr(data);

            $("#table_div").tabulator("setData", data);

            console.log(data);
        
            

        })

        .fail(function () {

            alert("Failed"); 

        });


}


//ConvertFormToJSON() calls serializeArray on the search form converting it to a array, the array is then converted to a JSON and returned
function ConvertFormToJSON() {

    var array = $('#search').serializeArray();

    var json = {};


    $.each(array, function () {

        json[this.name] = this.value || '';

    });


    return json;

}

//showMap() is called by the button (id = map_button), hides all elements except the map
//if the map has not been created yet, it creates it.
function showMap() {

    $("#table_div").hide();

    $("#timeline").hide();

    $("#map").show();

    $("#entry_info").hide();

    if (map == null) {

        initMap();  

    }

    placeMarkers(map_cords);

    google.maps.event.trigger(map, 'resize'); //refresh the map
}


//Called when a cell in the table with data that can be displayed is clicked
//hides all elements except the entry page, populates the entry page with complete data from the table
function showEntry(e, cell) {

    $("#table_div").hide();

    $("#timeline").hide();

    $("#map").hide();

    $("#entry_info").show();

    console.log(cell.getData());

    buildEntry(cell.getData());

}
//buildEntry(data) takes the data stored in the table and displays the hidden attributes in a separate view
function buildEntry(data) {

    var d = "n/a";

    if (data.date) {

        d = data.date.substr(0, 10)

    }

    $("#entry_song").html(data.song_title);

    $("#entry_performer").html("<b>Performer/Composer: </b> " + data.artist);

    $("#entry_candidate").html("<b>Candidate: </b> " + data.candidate_name);

    $("#entry_genre").html("<b>Genre: </b> " + data.genre);

    $("#entry_event_title").html("<b>Event Title: </b> " + data.event_title);

    $("#entry_event_type").html("<b>Type of Event/Media: </b> " + data.event_type);

    $("#entry_music_type").html("<b>Type of Music: </b> " + data.music_type);

    $("#entry_date").html("<b>Date: </b> " + data.date.substr(0,10));

    $("#entry_notes").html("<b>Notes: </b> " + data.notes);

}


//showTable() is called by the button (id = table_button), hides all elements except the table
function showTable() {

    $("#table_div").show();

    $("#timeline").hide();

    $("#entry_info").hide();

    $("#map").hide();

}

//////////////MAP//////////////////

//initMap() creates the google map object
function initMap() {

    var atlanta = { lat: 33.748995, lng: -84.387982 };

    var macon = { lat: 32.840695, lng: -83.632402 };

    map = new google.maps.Map(document.getElementById('map'), {

        zoom: 4,

        center: { lat: 58, lng: -148 },

        disableDefaultUI: true

    });

}

//getCords() pulls the lat and lng values from the table data for each row add the lat and lng values to the map_cords array
function getCords(data) {

    data.forEach(function (row) {

        if (row.lat != null && row.lng != null) {

            map_cords.push({song: row.song_title, candidate: row.candidate_name, city: row.city, state: row.state, zip: row.zip, lat: row.lat, lng: row.lng });

        }

    });

}

// Sets the map on all markers in the array.
function setMapOnAll(map) {

    for (var i = 0; i < map_markers.length; i++) {

        map_markers[i].setMap(map);

    }

}

// Removes the markers from the map, but keeps them in the array.
function clearMarkers() {

    setMapOnAll(null);

}

// Shows any markers currently in the array.
function showMarkers() {

    setMapOnAll(map);

}

// Adds a marker to the map and push to the array.
function addMarker(location) {

    var infowindow = new google.maps.InfoWindow({
        content: "Song Title"
    });

    var marker = new google.maps.Marker({

        position: location,

        map: map

    });

    marker.addListener('click', function () {
        console.log("Made listener");
        infowindow.open(map, marker);
    });

    markers.push(marker);

}

// Deletes all markers in the array by removing references to them.
function deleteMarkers() {

    clearMarkers();

    map_markers = [];

    map_cords = [];

}

//placeMarkers() places markers on the google map for each entry that contains a zipcode with latitude and longnitude
function placeMarkers(data) {

    data.forEach(function (row) {
        var infowindow;
        if (row.lat != null && row.lng != null) {
            infowindow = new google.maps.InfoWindow({
                content: "<b>Song Title</b>: " + row.song + "<br /><b>Candidate</b>:" + row.candidate + "<br /><b>City</b>: " + row.city + "<br /> <b>State</b>:" + row.state + "Zip: " + row.zip.substr(0, 5) + "<br/><b>Census Info</b>: <a href=\"https://factfinder.census.gov/bkmk/cf/1.0/en/zip/" + row.zip.substr(0,5) + "/ALL\" style=\"color: blue\"><i>U.S. Census</i></a>"
            });

            map_markers.push(new google.maps.Marker({

                position: { lat: row.lat, lng: row.lng },

                map: map

            }).addListener('click', function () {
                console.log("Made listener");
                infowindow.open(map, this);
            }));

        }

    });

    //*********Add Code to create info windows************ 

    //****************************************************
}

        //showTimeline() is called by the button (id = timeline_button), hides all elements except the timeline
        //if the timeline has not been created yet, it creates it.
function showTimeline() {

    $("#table_div").hide();

    $("#timeline").show();

    $("#map").hide();

    $("#entry_info").hide();


        loadTimeline(); 
        setTimeout(function(){
             addEvents();
        }, 500);
}


function loadTimeline(){
    
                
    tg1 = $("#timeline").timeline({
        "data_source":"json/test.json",
        "icon_folder":"timeglider/icons/",
        "min_zoom":15,
        "max_zoom":60, 
        "image_lane_height":100
    });
                
    tg_instance = tg1.data("timeline");
                
                
}

function buildObjArr(data){
    
    timelineObj = [];
    
    data.forEach(function (row) {
            
            var rando = Math.floor((Math.random()*1000)+1);
            timelineObj.push({
                id:"new_" + rando,
				title: row.song_title,
                description: "Performer: " + row.artist,
				startdate:row.date.substr(0,9),
				importance:50,
				icon:"circle_black.png",
				timelines:["trailtrax"]
            });


    });
}

function addEvents(){
        var i = 0;
        for(i = 0;i < timelineObj.length;i++){
            tg_instance.addEvent(timelineObj[i], true);
        }

}